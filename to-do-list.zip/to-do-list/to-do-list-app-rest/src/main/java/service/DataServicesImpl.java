package service;

import java.util.List;

import models.Task;

import org.springframework.beans.factory.annotation.Autowired;

import dao.DataDao;

/**
 * 
 * @author ANish Nath
 * 
 */
public class DataServicesImpl implements DataServices {

	@Autowired
	DataDao dataDao;

	public boolean create(Task task) throws Exception {
		return dataDao.addEntity(task);
	}

	public boolean delete(Long id) throws Exception {
		return dataDao.deleteEntity(id);

	}

	public Task getTask(Long id) throws Exception {
		return dataDao.getEntityById(id);
	}

	public List<Task> listAllTask() throws Exception {
		return dataDao.getEntityList();
	}

}
